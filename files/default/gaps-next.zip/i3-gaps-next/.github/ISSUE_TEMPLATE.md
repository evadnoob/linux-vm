Output of `i3 --moreversion 2>&- || i3 --version`:

_REPLACE: i3 version output_

URL to a logfile as per http://i3wm.org/docs/debugging.html:

_REPLACE: URL to logfile_

**What I did:**

_REPLACE: e.g. "I’m pressing Alt+j (focus left)"_

**What I saw:**

_REPLACE: e.g. "i3 changed focus to the window ABOVE the current window"_

**What I expected instead:**
_REPLACE: e.g. "Focus should be on the window to the left"_
